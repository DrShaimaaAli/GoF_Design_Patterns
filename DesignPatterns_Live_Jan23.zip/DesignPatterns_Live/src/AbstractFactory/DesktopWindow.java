package AbstractFactory;

public class DesktopWindow extends Window {
	
	public void openWindow() {
		System.out.println("DesktopWindow is now opened");
	}

}
