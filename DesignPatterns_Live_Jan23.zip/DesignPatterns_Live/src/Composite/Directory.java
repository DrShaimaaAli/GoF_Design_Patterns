package Composite;

import java.util.ArrayList;

public class Directory extends AbstractFile {
	
	ArrayList<AbstractFile> children;
	
	Directory(String fileName)
	{
		super(fileName);
		children = new ArrayList<AbstractFile>();
	}
	
	void addFile(AbstractFile file)
	{
		children.add(file);
	}
	
	void removeFile(AbstractFile file)
	{
		children.remove(file);
	}
	
	void open()
	 {
		 System.out.println("Opening a directory : "+ name);
		 
		 for(AbstractFile f: children)
			 f.open();
	 }
	 
	 void close()
	 {
		 System.out.println("Closing a directory: "+ name);
		 for(AbstractFile f: children)
			 f.close();
	 }

}
