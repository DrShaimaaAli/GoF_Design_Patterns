package FactoryMethod;

public abstract class OfficeApp {

	abstract Document createDocument();
	public void newDocument()
	{
		Document doc = createDocument() ;
		// common steps for creating the document
		doc.open();
	}
}
