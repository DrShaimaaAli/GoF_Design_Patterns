package Facade;

public class Crypto {

	String encrept(String data)
	{
		return "Encrypted version of " + data;
	}
	
	String decrept(String data)
	{
		return "Decrepted version of " + data;
	}
}
