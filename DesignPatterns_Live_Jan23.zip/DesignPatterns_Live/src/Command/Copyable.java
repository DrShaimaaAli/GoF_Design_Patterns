package Command;

public interface Copyable {

	abstract String copy_action();
}
