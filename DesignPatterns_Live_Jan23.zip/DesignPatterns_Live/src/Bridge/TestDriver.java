package Bridge;

public class TestDriver {
	
	public static void PowerSwitch_Client(PowerSwitch power)
	{
		//when the user decided to turn on the power
		power.on();
		
		//when the user decided to turn off the power
		power.off();	
	}
	
	public static void configurePowerSwitch(PowerSwitch power, SectionedLights lights)
	{	
		power.setLights(lights);
		PowerSwitch_Client(power);
	}
	
	public static void main(String[] args) {
	
		configurePowerSwitch(new PowerSwitch(),new AlternatingSectionedLights());
		
		System.out.println("================================");
		
		configurePowerSwitch(new PowerSwitch(),new RegularSectionedLights());
		
		System.out.println("#########################################################");
		
		configurePowerSwitch(new TimedPowerSwitch(),new AlternatingSectionedLights());
		
		System.out.println("================================");
		
		configurePowerSwitch(new TimedPowerSwitch(),new RegularSectionedLights());

	}
}
