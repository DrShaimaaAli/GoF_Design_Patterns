package TemplateMethod;

public class QuickSort extends DividAndConqureSortingTemplate {

	 void divide() {}
	 void conqure() {}
	 void combine() {}

}
