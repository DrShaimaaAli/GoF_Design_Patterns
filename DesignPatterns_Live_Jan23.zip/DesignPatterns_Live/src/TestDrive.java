import java.util.ArrayList;

public class TestDrive {
	public static void main(String[] args) {
		/*
		UserPrefs pref1 = UserPrefs.getInstace();
		pref1.setPrefColor("Red");
		
		UserPrefs pref2 = UserPrefs.getInstace();
		pref2.setPrefColor("Green");
		
		System.out.println("Pref1 Color: "+ pref1.getPrefColor());
		System.out.println("Pref2 Color: "+ pref2.getPrefColor());
		*/
		
		ArrayList<ArrayList<String>> list = new ArrayList<>();
		list.add(new ArrayList<>());
		list.add(new ArrayList<>());
		
		list.get(0).add("ABC");
		list.get(1).add("XYZ");
		
		
		ArrayList<ArrayList<String>> shallowCopy = (ArrayList<ArrayList<String>>) list.clone();
		
		
		System.out.println("Original List:" + list);
		System.out.println("Shallow Copy:" + shallowCopy);
		
		System.out.println("========================================================");
		
		shallowCopy.get(0).add("123");
		
		System.out.println("Original List:" + list);
		System.out.println("Shallow Copy:" + shallowCopy);
		
        System.out.println("========================================================");
		
		shallowCopy.add(new ArrayList<>() );
		shallowCopy.get(2).add("456");
		
		System.out.println("Original List:" + list);
		System.out.println("Shallow Copy:" + shallowCopy);
		
		System.out.println("========================================================");
		
		list.get(0).add("9999");
		
		System.out.println("Original List:" + list);
		System.out.println("Shallow Copy:" + shallowCopy);
		
		System.out.println("========================================================");
		
		list.add(new ArrayList<>() );
		list.get(2).add("2222");
		
		System.out.println("Original List:" + list);
		System.out.println("Shallow Copy:" + shallowCopy);
		
	}
}
