package AbstractFactory;

public class MobileScrollbar extends Scrollbar {

	 public void setLoc(int loc)
	 {
		 System.out.println("MobileScrollbar location is set to: "+ loc);
	 }

}
