package TemplateMethod;

public abstract class DividAndConqureSortingTemplate {
	
	public void sort()
	{
		divide();
		conqure();
		combine();
	}
	
	abstract void divide();
	abstract void conqure();
	abstract void combine();

}
