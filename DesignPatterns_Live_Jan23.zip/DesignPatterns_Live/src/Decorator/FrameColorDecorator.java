package Decorator;

public class FrameColorDecorator extends FrameDecorator {

	private String color;
	
	void drawTopBorder()
	 {
		 System.out.println("Drawing "+ color + " top border");
	 }
	 void drawRightBorder()
	 {
		 System.out.println("Drawing "+ color + " right border");
	 }
	 void drawLeftBorder()
	 {
		 System.out.println("Drawing "+ color + " left border");
	 }
	 void drawBottomBorder()
	 {
		 System.out.println("Drawing "+ color + " bottom border");
	 }

	String getColor() {
		return color;
	}

	void setColor(String color) {
		this.color = color;
	}
	
}
