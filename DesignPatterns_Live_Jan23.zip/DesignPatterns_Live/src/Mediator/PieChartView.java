package Mediator;

public class PieChartView extends Colleague{

	private String data;

	String getData() {
		return data;
	}
	
	PieChartView(Mediator med)
	{
		super(med);
	}

	void setData(String data) {
		this.data = data;
		mediator.Notify(this);
	}
	
	String getState()
	{
		return data;
	}
	
	void update(Colleague updatedColleague)
	{
		data = updatedColleague.getState();
		System.out.println("PieChartView object changed the state to: " + data);
	}
}
