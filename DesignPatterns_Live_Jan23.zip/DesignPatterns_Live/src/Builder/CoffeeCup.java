package Builder;

import java.util.ArrayList;

public class CoffeeCup {
	ArrayList<String> coffeeOrder; 
	
	CoffeeCup()
	{
		coffeeOrder = new ArrayList<String>();
	}
	
}
