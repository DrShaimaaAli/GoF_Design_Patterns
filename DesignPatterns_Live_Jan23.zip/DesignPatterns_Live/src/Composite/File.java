package Composite;

public class File extends AbstractFile {
	
	File(String fileName)
	{
		super(fileName);
	}
	
	 void open()
	 {
		 System.out.println("Opening a leaf file: "+ name);
	 }
	 
	 void close()
	 {
		 System.out.println("Closing a leaf file: "+ name);
	 }

}
