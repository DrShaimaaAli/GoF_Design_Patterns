package Visitor;

public abstract class VisitorFormatter {

	abstract void formateInPersonCourse(InPersonCourse course);
	abstract void formateOnlineCourse(OnlineCourse course);
}
