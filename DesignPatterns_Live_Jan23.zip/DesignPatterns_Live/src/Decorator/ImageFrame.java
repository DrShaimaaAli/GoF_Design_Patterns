package Decorator;

public abstract class ImageFrame {

	abstract void drawTopBorder();
	abstract void drawRightBorder();
	abstract void drawLeftBorder();
	abstract void drawBottomBorder();
	
}
