package Bridge;

public abstract class SectionedLights {

	abstract void turnedLightesOn();
	abstract void turnedLightesOff();
}
