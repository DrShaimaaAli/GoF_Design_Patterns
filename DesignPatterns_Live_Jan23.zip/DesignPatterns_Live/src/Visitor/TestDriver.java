package Visitor;

public class TestDriver {
	public static void main(String[] args) {
		GraphicalFormatter g = new GraphicalFormatter();
		PlainTextFormatter plain = new PlainTextFormatter();
		
		OnlineCourse online = new OnlineCourse();
		online.setCourseContent("Online Design Patterns");
		
		InPersonCourse inperson = new InPersonCourse();
		inperson.setCourseOutlines("OOD InPerson outlines");
		
		online.Accept(g);
		online.Accept(plain);
		
		
		inperson.Accept(g);
		inperson.Accept(plain);
	}
}
