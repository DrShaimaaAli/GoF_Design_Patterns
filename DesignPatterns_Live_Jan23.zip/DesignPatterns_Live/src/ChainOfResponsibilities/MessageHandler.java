package ChainOfResponsibilities;

public abstract class MessageHandler {

	abstract String processMessage(String msg);
	
	private MessageHandler successor;
	
	MessageHandler getSuccessor() {
		return successor;
	}

	void setSuccessor(MessageHandler successor) {
		this.successor = successor;
	}
	
	
	
}
