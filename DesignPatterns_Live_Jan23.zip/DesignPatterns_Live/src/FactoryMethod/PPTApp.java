package FactoryMethod;

public class PPTApp extends OfficeApp{

	Document createDocument()
	{
		return new PPTDocument();
	}
}
