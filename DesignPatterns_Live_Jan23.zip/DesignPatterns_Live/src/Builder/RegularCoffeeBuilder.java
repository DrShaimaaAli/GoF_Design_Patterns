package Builder;

public class RegularCoffeeBuilder extends CoffeeBuilder{

	void addSuger()
	 {
		 cup.coffeeOrder.add("Sugar");
	 }
	 
	 void addMilk()
	 {
		 cup.coffeeOrder.add("Milk");
	 }
	 
	 void addCream()
	 {
	 }
	 void addCoffee()
	 {
		 cup.coffeeOrder.add("Medium Roast Coffee");
	 }
	
}
