package Adapter;

public class Original_API {

	public void service()
	{
		System.out.println("Original implementation of the service");
	}
}
