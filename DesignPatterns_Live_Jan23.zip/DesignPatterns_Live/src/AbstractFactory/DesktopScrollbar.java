package AbstractFactory;

public class DesktopScrollbar extends Scrollbar {

	 public void setLoc(int loc)
	 {
		 System.out.println("DesktopScrollbar location is set to: "+ loc);
	 }


}
