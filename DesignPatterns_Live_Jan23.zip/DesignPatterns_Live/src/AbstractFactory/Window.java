package AbstractFactory;

public abstract class Window {
	
	public abstract void openWindow();
	
	// common functionanlities
}
