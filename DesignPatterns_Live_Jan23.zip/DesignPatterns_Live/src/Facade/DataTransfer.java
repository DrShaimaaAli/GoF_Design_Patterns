package Facade;

public class DataTransfer {
	String data;
	
	public void uploadData(String data)
	{
		this.data = data;
	}
	
	public String dowloadData()
	{
		return data;
	}
}
