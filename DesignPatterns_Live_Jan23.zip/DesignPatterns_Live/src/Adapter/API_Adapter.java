package Adapter;

public class API_Adapter extends Original_API {

	Updated_API updated = new Updated_API();
	
	public void service()
	{
		updated.updatedService();
	}

}
