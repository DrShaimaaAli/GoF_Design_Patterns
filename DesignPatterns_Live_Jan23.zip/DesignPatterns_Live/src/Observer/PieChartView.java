package Observer;

public class PieChartView extends Observer {

	void update(Subject sub)
	{
		String updatedState = sub.getState();
		System.out.println("PieChartView updated with: "+ updatedState);
	}

}
