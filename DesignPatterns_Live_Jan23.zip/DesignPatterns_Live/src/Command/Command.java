package Command;

public abstract class Command {
	
	abstract void execute(); 
	
}
