package Builder;

public class DoubleDoubleCoffeeBuilder extends CoffeeBuilder{

	 void addSuger()
	 {
		 cup.coffeeOrder.add("Sugar");
		 cup.coffeeOrder.add("Sugar");
	 }
	 
	 void addMilk()
	 {}
	 
	 void addCream()
	 {
		 cup.coffeeOrder.add("Cream");
		 cup.coffeeOrder.add("Cream");
	 }
	 void addCoffee()
	 {
		 cup.coffeeOrder.add("Medium Roast Coffee");
	 }
}
