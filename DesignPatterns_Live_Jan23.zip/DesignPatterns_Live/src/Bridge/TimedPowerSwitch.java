package Bridge;

public class TimedPowerSwitch extends PowerSwitch{

	public void configureTime() {}
	
	void on()
	 {
		System.out.println("Time to turn lights On");
		super.on();
	 }
	 
	 void off()
	 {
		 System.out.println("Time to turn lights Off");
		 super.off();
	 }
}
