package Strategy;

import java.util.List;

public abstract class SortingStrategy {
	abstract void sort(List toSort);
	
}
