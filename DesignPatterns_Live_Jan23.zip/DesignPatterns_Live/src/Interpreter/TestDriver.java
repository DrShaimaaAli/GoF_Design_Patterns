package Interpreter;

public class TestDriver {
	public static void main(String[] args) {
	
		// The match pattern a & b 
		LiteralExpression literal1 = new LiteralExpression();
		literal1.setLiteral("a");
		
		LiteralExpression literal2 = new LiteralExpression();
		literal2.setLiteral("b");
		
		SequenceExpression seq = new SequenceExpression();
		seq.setExpression1(literal1);
		seq.setExpression2(literal2);
		
		System.out.println(seq.isMatch("x"));
		System.out.println(seq.isMatch("ab"));
		System.out.println(seq.isMatch("a"));
		
	}
}
