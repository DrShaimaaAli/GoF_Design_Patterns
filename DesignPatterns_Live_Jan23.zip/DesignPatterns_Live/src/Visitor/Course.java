package Visitor;

public abstract class Course {

	abstract void Accept(VisitorFormatter visitor);
}
