package Interpreter;

public class LiteralExpression extends RegularExpression {
	private String literal;
	
	boolean isMatch(String toMatch) {
		return toMatch.contains(literal);
	}

	String getLiteral() {
		return literal;
	}

	void setLiteral(String literal) {
		this.literal = literal;
	}
}
