package Composite;

public abstract class AbstractFile {
	String name;
	AbstractFile(String name)
	{
		this.name = name;
	}
	
	abstract void open();
	abstract void close();
}
