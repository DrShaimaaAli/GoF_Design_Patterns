package Command;

public class Copy extends Command{
	private Copyable element;
	
	
	void execute()
	{
		System.out.println("Open Clipboard");
		
		//copying the element
		System.out.println(element.copy_action());
		
		System.out.println("Save copied element to Clipboard");
		System.out.println("Close Clipboard");
	}


	Copyable getElement() {
		return element;
	}


	void setElement(Copyable element) {
		this.element = element;
	}
}
