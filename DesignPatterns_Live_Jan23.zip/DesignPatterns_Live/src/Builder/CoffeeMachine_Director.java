package Builder;

public class CoffeeMachine_Director {

	public void makeCoffe(CoffeeBuilder builder)
	{
		builder.addSuger();
		builder.addMilk();
		builder.addCream();
		builder.addCoffee();
		
	}
}
