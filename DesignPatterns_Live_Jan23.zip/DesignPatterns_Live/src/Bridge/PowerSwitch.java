package Bridge;

public class PowerSwitch {

	private SectionedLights lights;
	
	 void on()
	 {
		 getLights().turnedLightesOn();
	 }
	 
	 void off()
	 {
		 getLights().turnedLightesOff();
	 }

	SectionedLights getLights() {
		return lights;
	}

	void setLights(SectionedLights lights) {
		this.lights = lights;
	}
}
