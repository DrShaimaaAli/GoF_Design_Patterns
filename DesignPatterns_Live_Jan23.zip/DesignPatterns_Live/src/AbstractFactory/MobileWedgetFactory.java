package AbstractFactory;

public class MobileWedgetFactory extends WedgetFactory{

	 Window createWindow()
	 {
		 return new MobileWindow();
	 }
	 
	 Scrollbar createScrollbar()
	 {
		 return new MobileScrollbar();
	 }

}
