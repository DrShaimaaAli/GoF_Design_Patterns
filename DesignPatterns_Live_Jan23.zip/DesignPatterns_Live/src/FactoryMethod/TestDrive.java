package FactoryMethod;

public class TestDrive {
	public static void main(String[] args) {
		OfficeApp app = new PPTApp();
		app.newDocument();
		
		app = new WordApp();
		app.newDocument();
	
		app = new ExcelApp();
		app.newDocument();
	}
}
