package Command;

public class Paragraph implements Copyable{

	String name;
	Paragraph(String name)
	{
		this.name = name;
	}
	
	public String copy_action()
	{
		return "A copy of :" + this.name;
	}

}
