package ChainOfResponsibilities;

public class ComplaintHandler extends MessageHandler {

	String processMessage(String msg)
	{
		//Logic that determine if it's a complaint
		if(msg.indexOf("complaint") != -1)
		{
			return "Message forwarded to the cusotmer service";
		}
		else
		{
			if (getSuccessor() != null)
				return getSuccessor().processMessage(msg);
			else
				return "Unkown Message";
		}
			
	}
}
