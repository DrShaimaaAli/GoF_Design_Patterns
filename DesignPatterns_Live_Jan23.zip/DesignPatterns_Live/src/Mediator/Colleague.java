package Mediator;

public abstract class Colleague {

	Mediator mediator;
	
	Colleague(Mediator med)
	{
		this.mediator = med;
	}
	
	abstract void update(Colleague updatedColleague);
	abstract String getState();
	
}
