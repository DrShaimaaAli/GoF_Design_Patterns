package Adapter;

public class Updated_API {

	public void updatedService()
	{
		System.out.println("Updated implementation");
	}
}
