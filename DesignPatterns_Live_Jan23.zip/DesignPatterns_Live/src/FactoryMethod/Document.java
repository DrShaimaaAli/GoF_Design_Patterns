package FactoryMethod;

public abstract class Document {
	// common methods for all documents
	abstract public void open();
}
