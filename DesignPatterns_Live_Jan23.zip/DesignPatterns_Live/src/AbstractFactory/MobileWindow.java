package AbstractFactory;

public class MobileWindow extends Window {
	
	public void openWindow() {
		System.out.println("MobileWindow is now opened");
	}

}
