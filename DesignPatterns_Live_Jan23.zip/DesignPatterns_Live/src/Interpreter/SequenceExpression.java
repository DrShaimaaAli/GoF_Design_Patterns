package Interpreter;

public class SequenceExpression extends RegularExpression {
	 private RegularExpression expression1;
	 private RegularExpression expression2;
	
	boolean isMatch(String toMatch)
	 {
		 return expression1.isMatch(toMatch) && expression2.isMatch(toMatch);
	 }

	RegularExpression getExpression1() {
		return expression1;
	}

	void setExpression1(RegularExpression expression1) {
		this.expression1 = expression1;
	}

	RegularExpression getExpression2() {
		return expression2;
	}

	void setExpression2(RegularExpression expression2) {
		this.expression2 = expression2;
	}

}
