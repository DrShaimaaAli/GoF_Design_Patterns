package FactoryMethod;

public class ExcelDocument extends Document {
	
	 public void open() {
		 System.out.println("Excel Document is opened");
	 }

}
