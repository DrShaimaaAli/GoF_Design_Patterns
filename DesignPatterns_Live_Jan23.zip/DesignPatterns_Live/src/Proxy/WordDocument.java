package Proxy;

import java.util.ArrayList;

public class WordDocument extends Document {
	ArrayList<String> textContent = new ArrayList();
	ArrayList<String> imageContent = new ArrayList();
	
	public void addText(String textLine)
	{
		textContent.add(textLine);
	}
	
	public void addImage(String image)
	{
		imageContent.add(image);
	}
	
	public void loadFile()
	{
		for(String text: textContent)
			System.out.println(text);
		
		for(String img: imageContent)
			System.out.println(img);
	}
}
