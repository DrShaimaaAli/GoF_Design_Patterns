package Strategy;

import java.util.List;

public class BubbleSort extends SortingStrategy {
	void sort(List toSort) {
		System.out.println("Bubble Sort");
	}

}
