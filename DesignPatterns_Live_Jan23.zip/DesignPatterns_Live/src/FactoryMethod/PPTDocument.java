package FactoryMethod;

public class PPTDocument extends Document {
	
	 public void open() {
		 System.out.println("PPT Document is opened");
	 }

}
