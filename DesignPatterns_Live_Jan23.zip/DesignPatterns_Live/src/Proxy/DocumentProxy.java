package Proxy;

public class DocumentProxy extends Document{

	private WordDocument doc;
	
	void loadFile()
	{
	
		for(String text: doc.textContent)
			System.out.println(text);
		
		for(String img: doc.imageContent)
		{
			System.out.println("Wait for the trigger ....");
			System.out.println(img);
		}
	}

	WordDocument getDoc() {
		return doc;
	}

	void setDoc(WordDocument doc) {
		this.doc = doc;
	}
}
