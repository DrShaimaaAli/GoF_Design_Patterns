package TemplateMethod;

public class MergeSort extends DividAndConqureSortingTemplate {

	 void divide() {}
	 void conqure() {}
	 void combine() {}
}
