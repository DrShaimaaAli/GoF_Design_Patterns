package Mediator;

public class TestDriver {
	public static void main(String[] args) {
		Mediator mediator = new Mediator();
		
		TableView table = new TableView(mediator);
		PieChartView pie = new PieChartView(mediator);
		Data data = new Data(mediator);
		
		mediator.addColleague(table);
		mediator.addColleague(pie);
		mediator.addColleague(data);
		
		table.setData("ABC");
		System.out.println("=============================");
		pie.setData("XYZ");
		System.out.println("=============================");
		data.setData("LMN");
		
	}
}
