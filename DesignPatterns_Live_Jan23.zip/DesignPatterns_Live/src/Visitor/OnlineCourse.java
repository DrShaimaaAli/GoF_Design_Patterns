package Visitor;

public class OnlineCourse extends Course{
	
	private String courseContent;

	String getCourseContent() {
		return courseContent;
	}

	void setCourseContent(String courseContent) {
		this.courseContent = courseContent;
	}
	
	void Accept(VisitorFormatter visitor)
	{
		visitor.formateOnlineCourse(this);
	}
}
