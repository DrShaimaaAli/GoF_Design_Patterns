package Observer;

public class TestDriver {
	public static void main(String[] args) {
		Data dataSubject = new Data();
		
		TableView table1 = new TableView();
		dataSubject.attach(table1);
		TableView table2 = new TableView();
		dataSubject.attach(table2);
		
		PieChartView pie = new PieChartView();
		dataSubject.attach(pie);
		
		
		dataSubject.setData("ABC");
		
		dataSubject.setData("XYZ");
		
	}
}
