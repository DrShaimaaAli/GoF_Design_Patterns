package Builder;

public abstract class CoffeeBuilder {
	CoffeeCup cup;
	CoffeeBuilder()
	{
		cup = new CoffeeCup();
	}
	
	CoffeeCup getResult()
	{
		return cup;
	}
	
	abstract void addSuger();
	abstract void addMilk();
	abstract void addCream();
	abstract void addCoffee();
	
}
