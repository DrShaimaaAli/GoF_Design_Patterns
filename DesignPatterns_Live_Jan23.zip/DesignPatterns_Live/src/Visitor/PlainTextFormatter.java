package Visitor;

public class PlainTextFormatter extends VisitorFormatter {

	 void formateInPersonCourse(InPersonCourse course)
	 {
		 String outlines = course.getCourseOutlines();
		 System.out.println("Add PlainText Representation to: " + outlines);
	 }
	 
	 void formateOnlineCourse(OnlineCourse course)
	 {
		 String content = course.getCourseContent();
		 System.out.println("Add PlainText Representation to: " + content);
	 }
}
