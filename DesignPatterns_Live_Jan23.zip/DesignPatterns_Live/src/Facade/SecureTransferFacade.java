package Facade;

public class SecureTransferFacade {

	Crypto secure = new Crypto();
	DataTransfer transfer = new DataTransfer();
	
	String encrept(String data)
	{
		System.out.println("Calling encrypt");
		return secure.encrept(data);
	}
	
	String decrept(String data)
	{
		System.out.println("Calling decrypt");

		return secure.decrept(data);
	}
	
	public void uploadData(String data)
	{
		System.out.println("Calling upload");

		transfer.uploadData(data);
	}
	
	public String dowloadData()
	{
		System.out.println("Calling download");

		return transfer.dowloadData();
	}
	
}
