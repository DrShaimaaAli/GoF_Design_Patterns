package Proxy;

public abstract class Document {

	abstract void loadFile();
}
