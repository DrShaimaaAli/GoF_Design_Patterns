package Observer;

import java.util.ArrayList;

public abstract class Subject {

	ArrayList<Observer> observers = new ArrayList<Observer>();
	
	public void attach(Observer observer)
	{
		observers.add(observer);
	}
	
	public void dettach(Observer observer)
	{
		observers.remove(observer);
	}
	
	abstract String getState();
	
	public void Notify()
	{
		for (Observer ob: observers)
			ob.update(this);
	}
	
}
