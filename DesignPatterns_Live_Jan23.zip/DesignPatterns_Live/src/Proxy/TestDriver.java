package Proxy;

public class TestDriver {
	
	public static void DocumentReader_client(Document doc)
	{
		doc.loadFile();
	}
	
	public static void main(String[] args) {
	
		WordDocument doc = new WordDocument();
		doc.addText("Line1");
		doc.addText("Line2");
		doc.addText("Line3");
		
		doc.addImage("img1");
		doc.addImage("img2");
		doc.addImage("img3");
		
		DocumentReader_client(doc);
		
		System.out.println("=============================");
		
		DocumentProxy proxy = new DocumentProxy();
		proxy.setDoc(doc);
		
		DocumentReader_client(proxy);
	}
}
