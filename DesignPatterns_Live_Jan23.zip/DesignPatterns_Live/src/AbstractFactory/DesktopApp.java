package AbstractFactory;

public class DesktopApp extends Application {
	
	DesktopApp()
	{
		factory = new DesktopWedgetFactory();
	}
}
