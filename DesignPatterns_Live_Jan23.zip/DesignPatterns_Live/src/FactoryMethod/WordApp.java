package FactoryMethod;

public class WordApp extends OfficeApp{

	Document createDocument()
	{
		return new WordDocument();
	}

}
