package Observer;

public class TableView extends Observer {

	void update(Subject sub)
	{
		String updatedState = sub.getState();
		System.out.println("Tableview updated with: "+ updatedState);
	}

}
