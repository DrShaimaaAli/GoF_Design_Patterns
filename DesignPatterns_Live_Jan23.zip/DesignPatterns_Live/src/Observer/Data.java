package Observer;

public class Data extends Subject{
	
	private String data;

	String getData() {
		return data;
	}

	void setData(String data) {
		this.data = data;
		Notify();
	}
	
	public String getState()
	{
		return data;
	}
	
}
