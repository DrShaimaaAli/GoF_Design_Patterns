package Strategy;

import java.util.ArrayList;

public class TestDriver {
	
	public static void executingSorting(SortingStrategy sorting, ArrayList<String> list)
	{
		sorting.sort(list);
	}
	
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("A");
		list.add("X");
		list.add("D");
		
		
		executingSorting(new BubbleSort(), list);
		
		executingSorting(new MergeSort(), list);
		executingSorting(new QuickSort(), list);
		
	}
}
