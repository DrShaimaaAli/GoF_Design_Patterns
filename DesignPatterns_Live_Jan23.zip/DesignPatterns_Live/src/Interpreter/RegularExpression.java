package Interpreter;

public abstract class RegularExpression {
	abstract boolean isMatch(String toMatch);
}
