package TemplateMethod;

public class TestDriver {
	public static void main(String[] args) {
		DividAndConqureSortingTemplate sortTemplate = new MergeSort();
		
		sortTemplate.sort();
	}
}
