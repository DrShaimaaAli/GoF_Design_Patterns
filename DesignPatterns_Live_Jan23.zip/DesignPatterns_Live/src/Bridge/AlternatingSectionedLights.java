package Bridge;

public class AlternatingSectionedLights extends SectionedLights {

	void turnedLightesOn()
	 {
		System.out.println("AlternatingSectionedLights truned on");
	 }
	
	void turnedLightesOff()
	{
		System.out.println("AlternatingSectionedLights truned off");
	}

}
