package Decorator;

public class FrameDecorator extends ImageFrame {

	 private ImageFrame frame;
	
	
	 void drawTopBorder()
	 {
		 frame.drawTopBorder();
	 }
	 void drawRightBorder()
	 {
		 frame.drawRightBorder();
	 }
	 void drawLeftBorder()
	 {
		 frame.drawLeftBorder();
	 }
	 void drawBottomBorder()
	 {
		 frame.drawBottomBorder();
	 }


	ImageFrame getFrame() {
		return frame;
	}
	void setFrame(ImageFrame frame) {
		this.frame = frame;
	}
}