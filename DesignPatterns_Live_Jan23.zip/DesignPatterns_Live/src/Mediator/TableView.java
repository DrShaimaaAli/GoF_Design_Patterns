package Mediator;

public class TableView extends Colleague{

	private String data;

	TableView(Mediator med)
	{
		super(med);
	}
	String getData() {
		return data;
	}

	void setData(String data) {
		this.data = data;
		
		mediator.Notify(this);
	}
	
	String getState()
	{
		return data;
	}
	
	void update(Colleague updatedColleague)
	{
		data = updatedColleague.getState();
		System.out.println("TableView object changed the state to: " + data);
	}
}
