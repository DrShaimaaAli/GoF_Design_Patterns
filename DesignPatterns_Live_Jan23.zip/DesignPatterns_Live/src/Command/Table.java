package Command;

public class Table implements Copyable{

	String name;
	Table(String name)
	{
		this.name = name;
	}
	
	public String copy_action()
	{
		return "A copy of :" + this.name;
	}
}
