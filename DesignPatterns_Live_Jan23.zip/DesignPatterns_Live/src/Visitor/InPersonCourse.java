package Visitor;

public class InPersonCourse extends Course{
	private String courseOutlines;

	String getCourseOutlines() {
		return courseOutlines;
	}

	void setCourseOutlines(String courseOutlines) {
		this.courseOutlines = courseOutlines;
	}
	
	void Accept(VisitorFormatter visitor)
	{
		visitor.formateInPersonCourse(this);
	}
}
