package Visitor;

public class GraphicalFormatter extends VisitorFormatter {

	 void formateInPersonCourse(InPersonCourse course)
	 {
		 String outlines = course.getCourseOutlines();
		 System.out.println("Add Graphical Representation to: " + outlines);
	 }
	 
	 void formateOnlineCourse(OnlineCourse course)
	 {
		 String content = course.getCourseContent();
		 System.out.println("Add Graphical Representation to: " + content);
	 }

}
