package Command;

public class Image implements Copyable{

	String name;
	Image(String name)
	{
		this.name = name;
	}
	
	public String copy_action()
	{
		return "A copy of :" + this.name;
	}
}
