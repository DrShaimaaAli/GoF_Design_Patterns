package Decorator;

public class RegularFrame extends ImageFrame {

	 void drawTopBorder()
	 {
		 System.out.println("Drawing regular top border");
	 }
	 void drawRightBorder()
	 {
		 System.out.println("Drawing regular right border");
	 }
	 void drawLeftBorder()
	 {
		 System.out.println("Drawing regular left border");
	 }
	 void drawBottomBorder()
	 {
		 System.out.println("Drawing regular bottom border");
	 }

}
