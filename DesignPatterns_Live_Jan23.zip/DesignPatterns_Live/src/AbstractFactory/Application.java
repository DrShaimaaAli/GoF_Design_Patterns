package AbstractFactory;

public abstract class Application {
	
	WedgetFactory factory;
	public void open()
	{
		//common steps
		Window window = factory.createWindow();
		Scrollbar scroll = factory.createScrollbar();
		
		window.openWindow();
		scroll.setLoc(0);
	}
}
