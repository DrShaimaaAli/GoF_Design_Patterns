package AbstractFactory;

public class DesktopWedgetFactory extends WedgetFactory {

	Window createWindow()
	 {
		 return new DesktopWindow();
	 }
	 
	 Scrollbar createScrollbar()
	 {
		 return new DesktopScrollbar();
	 }
}
