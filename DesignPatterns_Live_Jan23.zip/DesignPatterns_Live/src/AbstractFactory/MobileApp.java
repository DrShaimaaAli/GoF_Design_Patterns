package AbstractFactory;

public class MobileApp extends Application {
	
	MobileApp()
	{
		factory = new MobileWedgetFactory();
	}
}
