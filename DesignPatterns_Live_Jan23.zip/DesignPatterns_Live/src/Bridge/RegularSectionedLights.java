package Bridge;

public class RegularSectionedLights extends SectionedLights {

	void turnedLightesOn()
	 {
		System.out.println("RegularSectionedLights truned on");
	 }
	
	void turnedLightesOff()
	{
		System.out.println("RegularSectionedLights truned off");
	}
}
