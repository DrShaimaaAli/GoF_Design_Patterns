package FactoryMethod;

public class ExcelApp extends OfficeApp{

	Document createDocument()
	{
		return new ExcelDocument();
	}

}
