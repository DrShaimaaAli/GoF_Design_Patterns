
public class UserPrefs {
	private String prefColor;
	private String prefFont;
	
	private static UserPrefs singleton;
	
	private UserPrefs()
	{
		System.out.println("The constructor is called");
	}
	
	public static UserPrefs getInstace()
	{
		if (singleton == null)
			singleton = new UserPrefs();
		
		return singleton;
	}
	
	String getPrefColor() {
		return prefColor;
	}
	void setPrefColor(String prefColor) {
		this.prefColor = prefColor;
	}
	String getPrefFont() {
		return prefFont;
	}
	void setPrefFont(String prefFont) {
		this.prefFont = prefFont;
	}
	
}
