package Composite;

public class TestDriver {
	
	public static void main(String[] args) {
		Directory homeDir = new Directory("Home");
		
		homeDir.addFile(new File("ReadMe.txt"));
		homeDir.addFile(new File("TodoList.txt"));
		homeDir.addFile(new Directory("Downloads"));
		
		homeDir.open();
		System.out.println("=====================");
		homeDir.close();
		
		
	}
}
