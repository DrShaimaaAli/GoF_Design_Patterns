package ChainOfResponsibilities;

public class SpamHandler extends MessageHandler {

	String processMessage(String msg)
	{
		//Logic that determine if it's a spam
		if(msg.indexOf("spam") != -1)
		{
			return "Message moved to the spam folder";
		}
		else
		{
			if (getSuccessor() != null)
				return getSuccessor().processMessage(msg);
			else
				return "Unkown Message";
		}
			
	}

}
