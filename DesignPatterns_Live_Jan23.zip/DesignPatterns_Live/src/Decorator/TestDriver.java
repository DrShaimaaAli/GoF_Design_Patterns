package Decorator;

public class TestDriver {
	
	public static void Frame_Client(ImageFrame frame)
	{
		frame.drawTopBorder();
		frame.drawRightBorder();
		frame.drawLeftBorder();
		frame.drawBottomBorder();
	}
	
	public static void main(String[] args) {
	
		RegularFrame regularFrame = new RegularFrame();
		Frame_Client(regularFrame);
		
		System.out.println("=================================================");
		
		FrameShadowDecorator shadow = new FrameShadowDecorator();
		shadow.setFrame(regularFrame);
		Frame_Client(shadow);
		
		System.out.println("=================================================");
		
		FrameColorDecorator colorFrame = new FrameColorDecorator();
		colorFrame.setFrame(regularFrame);
		colorFrame.setColor("Red");
		Frame_Client(colorFrame);
		
		System.out.println("=================================================");
		
		FrameShadowDecorator coloredShadowedFrame = new FrameShadowDecorator(); 
		coloredShadowedFrame.setFrame(colorFrame);
		Frame_Client(coloredShadowedFrame);
	}
}
