package Decorator;

public class FrameShadowDecorator extends FrameDecorator{

	 void drawLeftBorder()
	 {
		 super.drawLeftBorder();
		 System.out.println("Adding a Shadow");
	 }
	 void drawBottomBorder()
	 {
		 super.drawBottomBorder();
		 System.out.println("Adding a Shadow");
	 }
}
