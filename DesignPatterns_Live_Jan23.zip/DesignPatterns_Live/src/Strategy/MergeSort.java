package Strategy;

import java.util.List;

public class MergeSort extends SortingStrategy {
	void sort(List toSort) {
		System.out.println("Merge Sort");
	}
}
