package Strategy;

import java.util.List;

public class QuickSort extends SortingStrategy {
	void sort(List toSort) {
		System.out.println("Quick Sort");
	}

}
