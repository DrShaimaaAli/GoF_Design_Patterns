package Command;

import java.util.ArrayList;

public class TestDriver {
	public static void main(String[] args) {
		Image img = new Image("Logo Image");
		Table tbl = new Table("Table of Contents");
		Paragraph para = new Paragraph("Description");
		
		Copy copyCommand = new Copy();
		// other commands as well
		
		ArrayList<Command> contextMenu = new ArrayList();
		contextMenu.add(copyCommand);
		
		//the user opens the context menu on the img object
		copyCommand.setElement(img);
		copyCommand.execute();
		
		System.out.println("======================================");
		
		//the user opens the context menu on the tbl object
		copyCommand.setElement(tbl);
		copyCommand.execute();
		
		System.out.println("======================================");
		
		//the user opens the context menu on the para object
		copyCommand.setElement(para);
		copyCommand.execute();
		
	}
}
