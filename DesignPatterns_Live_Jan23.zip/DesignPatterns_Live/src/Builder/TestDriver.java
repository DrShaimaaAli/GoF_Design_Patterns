package Builder;

public class TestDriver {
	public static void main(String[] args) {
		CoffeeBuilder builder = new DoubleDoubleCoffeeBuilder();
		CoffeeMachine_Director director = new CoffeeMachine_Director();
		director.makeCoffe(builder);
		
		CoffeeCup cup = builder.getResult();
		
		System.out.println(cup.coffeeOrder);
		
		
		builder = new RegularCoffeeBuilder();
		director = new CoffeeMachine_Director();
		director.makeCoffe(builder);
		
		cup = builder.getResult();
		
		System.out.println(cup.coffeeOrder);
	}
}
