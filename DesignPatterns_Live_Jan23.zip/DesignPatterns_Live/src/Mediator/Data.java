package Mediator;

public class Data extends Colleague{

	private String data;

	Data(Mediator med)
	{
		super(med);
	}
	
	String getData() {
		return data;
	}

	void setData(String data) {
		this.data = data;
		mediator.Notify(this);
	}
	
	void update(Colleague updatedColleague)
	{
		data = updatedColleague.getState();
		System.out.println("Data object changed the state to: " + data);
	}
	
    String getState()
	{
		return data;
	}
}
