package ChainOfResponsibilities;

public class TestDriver {
	
	public static void main(String[] args) {
		
		
		
		FanHandler fanHandler = new FanHandler();
		SpamHandler spamHandler = new SpamHandler();
		ComplaintHandler complaintHandler = new ComplaintHandler();
		
		// 1.Fan 2.Complaint 3.spam
		// configured the chain
		fanHandler.setSuccessor(complaintHandler);
		complaintHandler.setSuccessor(spamHandler);
		
		//configure the client
		EmailReciever reciever = new EmailReciever(fanHandler);
		reciever.recieveEmail("something else Message");
		//System.out.println();
		
	}
}
