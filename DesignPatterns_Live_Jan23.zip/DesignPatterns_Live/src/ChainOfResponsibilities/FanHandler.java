package ChainOfResponsibilities;

public class FanHandler extends MessageHandler {

	String processMessage(String msg)
	{
		//Logic that determine if it's a fan
		if(msg.indexOf("fan") != -1)
		{
			return "Message forwarded to the rewards department";
		}
		else
		{
			if (getSuccessor() != null)
				return getSuccessor().processMessage(msg);
			else
				return "Unkown Message";
		}
			
	}

}
