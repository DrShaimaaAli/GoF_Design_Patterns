package AbstractFactory;

public abstract class Scrollbar {

	abstract public void setLoc(int loc);
	//common implementations
}
