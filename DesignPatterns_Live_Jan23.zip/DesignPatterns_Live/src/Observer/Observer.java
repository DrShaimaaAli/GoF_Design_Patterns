package Observer;

public abstract class Observer {

	abstract void update(Subject sub);
}
