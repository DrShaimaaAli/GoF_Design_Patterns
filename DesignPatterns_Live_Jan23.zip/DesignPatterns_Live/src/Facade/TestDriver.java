package Facade;

public class TestDriver {
	
	public static void main(String[] args) {
	
		SecureTransferFacade facade = new SecureTransferFacade();
		String encrypted = facade.encrept("ABC");
		facade.uploadData(encrypted);
		
		encrypted = facade.dowloadData();
		System.out.println(facade.decrept(encrypted));
		
	}
}
