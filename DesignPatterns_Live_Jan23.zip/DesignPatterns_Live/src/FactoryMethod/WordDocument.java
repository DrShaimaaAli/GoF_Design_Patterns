package FactoryMethod;

public class WordDocument extends Document {
	
	 public void open() {
		 System.out.println("Word Document is opened");
	 }

}
