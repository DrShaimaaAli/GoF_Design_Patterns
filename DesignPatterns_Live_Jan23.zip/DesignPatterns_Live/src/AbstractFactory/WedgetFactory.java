package AbstractFactory;

public abstract class WedgetFactory {

	abstract Window createWindow();
	abstract Scrollbar createScrollbar();
}
